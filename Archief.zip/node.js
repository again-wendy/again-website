require('dotenv').config();

const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const exphbs = require('express-handlebars');
const path = require('path');
const nodemailer = require('nodemailer');

const app = express();

// View engine setup
app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

// Static folder
app.use('/public', express.static(path.join(__dirname, 'public')));

// Body Parser Middleware
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.render('home');
});

app.post('/send', (req, res) => {

    let output = `
        <h1>Contact Form AGAIN.nl</h1>
        <h2>Details:</h2>
        <ul>
            <li>Name: ${req.body.name}</li>
            <li>Email: <a href="mailto:${req.body.email}">${req.body.email}</a></li>
            <li>Subject: ${req.body.subject}</li>
        </ul>
        <h4 style="margin-bottom:0;">Message:</h4> 
        <p>${req.body.msg}</p>
    `;

    let transporter = nodemailer.createTransport({
        host: "smtp.sendgrid.net",
        secure: false,
        port: 25,
        auth: {
            user: process.env.SENDGRID_USER,
            pass: process.env.SENDGRID_PASS
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    
    let HelperOptions = {
        from: '"Contact Form AGAIN website" <curious@again.nl>',
        to: 'wendy.dimmendaal@again.nl',
        subject: 'Reactie contactformulier AGAIN',
        text: 'Test 123',
        html: output
    };

    if( req.body['g-recaptcha-response'] === undefined || 
        req.body['g-recaptcha-response'] === '' ||
        req.body['g-recaptcha-response'] === null ) {
        
            res.render('error', {errorMsg: "Please select captcha"});
    }

    var secKey = process.env.GOOGLE_SECRET_KEY;
    var veriUrl = "https://www.google.com/recaptcha/api/siteverify?secret=" + secKey + "&response=" + req.body['g-recaptcha-response'] + "&remoteip=" + req.connection.remoteAddress;

    request(veriUrl, function(error, res, body) {
        body = JSON.parse(body);
        if(body.success !== undefined && !body.success) {
            res.render('error', {errorMsg: "The form was not sent"});
        }
        transporter.sendMail(HelperOptions, (err, info) => {
            if(err) {
                res.render('error', {errorMsg: err});
            }
            res.redirect('/?form=send');
        });
    });
})

var port = process.env.port || 3000;
app.listen(port, () => {
    console.log('Server started...');
});